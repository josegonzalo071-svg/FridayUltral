export function init() {
  // Aquí en el futuro puedes agregar sistema de progreso, estadísticas, etc.
  console.log("Memory module loaded (placeholder).");
}
